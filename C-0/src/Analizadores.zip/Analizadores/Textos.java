package Analizadores;

public class Textos
{
    static final String simboloRedeclarado = "El simbolo ya ha sido declarado anteriormente";
    static final String simboloNoDeclarado = "El simbolo no ha sido declarado previamente";
    static final String breakSinWhile = "Se ha utilizado un break fuera de un bloque while";
    static final String ficheroCiNoExiste = "El fichero del CI no existe";
}
