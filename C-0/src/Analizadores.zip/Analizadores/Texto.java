package Analizadores;

public class Texto {
    static final String breakSinWhile = "Se ha utilizado un break fuera de un bloque while";
    static final String simboloRedeclarado = "Este dentificador ya esta declarado";
    static final String simboloNoDeclarado = "Este simbolo no ha sido declarado";
    static final String errorAbrirFicheroLectura = "Error al abrir fichero de lectura";
    static final String errorCerrarFicheroLectura = "Error al cerrar fichero de lectura";
    static final String errorAbrirFicheroEscritura = "Error al abrir fichero de escritura";
    
}
