/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Analizadores;

/**
 *
 * @author GEOVANNI
 */
public class Expresion {
    private int direccion;

	Expresion(int d) {
		direccion = d;
	}
	
	int getDireccion() {
		return direccion;
	}
        
        public String toString(){
            return direccion + "";
        }
}
